const express = require("express");
const authRoutes = require("./auth.routes");
const bookRoutes = require("./book.routes");
const libraryRoutes = require("./library.routes");
const borrowRoutes = require("./borrow.routes");

const router = express.Router();

router.use("/auth", authRoutes);
router.use("/books", bookRoutes);
router.use("/libraries", libraryRoutes);
router.use("/", borrowRoutes); // For /borrow and /return routes

module.exports = router;
