const express = require("express");
const authController = require("../controllers/auth.controller");
const { authenticate } = require("../middlewares");
const { registerValidation, loginValidation } = require("../validators");

const router = express.Router();

router.post("/register", registerValidation, authController.register);
router.post("/login", loginValidation, authController.login);
router.get("/profile", authenticate, authController.getProfile);

module.exports = router;
