const { registerValidation, loginValidation } = require("./auth.validator");
const { bookValidation, updateBookValidation } = require("./book.validator");
const {
  libraryValidation,
  addBookToLibraryValidation,
} = require("./library.validator");
const { borrowValidation } = require("./borrow.validator");
module.exports = {
  registerValidation,
  loginValidation,
  bookValidation,
  updateBookValidation,
  libraryValidation,
  addBookToLibraryValidation,
  borrowValidation,
};
