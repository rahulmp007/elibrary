const authController = require("./auth.controller");
const bookController = require("./book.controller");
const libraryController = require("./library.controller");
const borrowController = require("./borrow.controller");

module.exports = {
  authController,
  bookController,
  libraryController,
  borrowController,
};
