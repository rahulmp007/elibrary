const libraryService = require("../services/library.service");
const { sendSuccess, sendCreated } = require("../utils");
const { MESSAGES } = require("../config/constants");

class LibraryController {
  async getAllLibraries(req, res, next) {
    try {
      const result = await libraryService.getAllLibraries(req.query);
      sendSuccess(res, "Libraries retrieved successfully", result);
    } catch (error) {
      next(error);
    }
  }

  async getLibraryById(req, res, next) {
    try {
      const library = await libraryService.getLibraryById(req.params.id);
      sendSuccess(res, "Library retrieved successfully", { library });
    } catch (error) {
      next(error);
    }
  }

  async createLibrary(req, res, next) {
    try {
      const library = await libraryService.createLibrary(req.body);
      sendCreated(res, MESSAGES.LIBRARY_CREATED, { library });
    } catch (error) {
      next(error);
    }
  }

  async updateLibrary(req, res, next) {
    try {
      const library = await libraryService.updateLibrary(
        req.params.id,
        req.body,
      );
      sendSuccess(res, MESSAGES.LIBRARY_UPDATED, { library });
    } catch (error) {
      next(error);
    }
  }

  async deleteLibrary(req, res, next) {
    try {
      await libraryService.deleteLibrary(req.params.id);
      sendSuccess(res, MESSAGES.LIBRARY_DELETED);
    } catch (error) {
      next(error);
    }
  }

  async getLibraryInventory(req, res, next) {
    try {
      const result = await libraryService.getLibraryInventory(
        req.params.id,
        req.query,
      );
      sendSuccess(res, "Library inventory retrieved successfully", result);
    } catch (error) {
      next(error);
    }
  }

  async addBookToLibrary(req, res, next) {
    try {
      const book = await libraryService.addBookToLibrary(
        req.params.id,
        req.body.bookId,
      );
      sendSuccess(res, MESSAGES.BOOK_ADDED_TO_LIBRARY, { book });
    } catch (error) {
      next(error);
    }
  }

  async removeBookFromLibrary(req, res, next) {
    try {
      await libraryService.removeBookFromLibrary(
        req.params.id,
        req.params.bookId,
      );
      sendSuccess(res, MESSAGES.BOOK_REMOVED_FROM_LIBRARY);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new LibraryController();
