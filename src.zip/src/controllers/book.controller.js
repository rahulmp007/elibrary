const bookService = require("../services/book.service");
const { sendSuccess, sendCreated } = require("../utils");
const { MESSAGES } = require("../config/constants");

class BookController {
  async getAllBooks(req, res, next) {
    try {
      const result = await bookService.getAllBooks(req.query, req.user._id);
      sendSuccess(res, "Books retrieved successfully", result);
    } catch (error) {
      next(error);
    }
  }

  async getBookById(req, res, next) {
    try {
      const book = await bookService.getBookById(req.params.id);
      sendSuccess(res, "Book retrieved successfully", { book });
    } catch (error) {
      next(error);
    }
  }

  async createBook(req, res, next) {
    try {
      const book = await bookService.createBook(
        req.body,
        req.user._id,
        req.file,
      );
      sendCreated(res, MESSAGES.BOOK_CREATED, { book });
    } catch (error) {
      next(error);
    }
  }

  async updateBook(req, res, next) {
    try {
      const book = await bookService.updateBook(
        req.params.id,
        req.body,
        req.user._id,
        req.file,
      );
      sendSuccess(res, MESSAGES.BOOK_UPDATED, { book });
    } catch (error) {
      next(error);
    }
  }

  async deleteBook(req, res, next) {
    try {
      await bookService.deleteBook(req.params.id, req.user._id);
      sendSuccess(res, MESSAGES.BOOK_DELETED);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new BookController();
