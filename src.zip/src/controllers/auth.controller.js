const authService = require("../services/auth.service");
const { sendSuccess, sendCreated } = require("../utils");
const { MESSAGES } = require("../config/constants");

class AuthController {
  async register(req, res, next) {
    try {
      const { user, token } = await authService.register(req.body);

      sendCreated(res, MESSAGES.USER_CREATED, { user, token });
    } catch (error) {
      next(error);
    }
  }

  async login(req, res, next) {
    try {
      const { email, password } = req.body;
      const { user, token } = await authService.login(email, password);

      sendSuccess(res, MESSAGES.LOGIN_SUCCESS, { user, token });
    } catch (error) {
      next(error);
    }
  }

  async getProfile(req, res) {
    sendSuccess(res, "Profile retrieved successfully", { user: req.user });
  }
}

module.exports = new AuthController();
