const authService = require("./auth.service");
const bookService = require("./book.service");
const libraryService = require("./library.service");
const borrowService = require("./borrow.service");
const uploadService = require("./upload.service");

module.exports = {
  authService,
  bookService,
  libraryService,
  borrowService,
  uploadService,
};
