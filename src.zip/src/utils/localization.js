const messages = {
  en: {
    auth: {
      tokenRequired: 'Access token is required',
      userNotFound: 'User not found',
      invalidToken: 'Invalid token',
      unauthorized: 'Unauthorized access',
      loginSuccess: 'Login successful',
      registrationSuccess: 'User registered successfully',
      invalidCredentials: 'Invalid email or password'
    },
    book: {
      created: 'Book created successfully',
      updated: 'Book updated successfully',
      deleted: 'Book deleted successfully',
      notFound: 'Book not found',
      borrowed: 'Book borrowed successfully',
      returned: 'Book returned successfully',
      alreadyBorrowed: 'Book is already borrowed',
      notBorrowed: 'Book is not currently borrowed'
    },
    library: {
      created: 'Library created successfully',
      updated: 'Library updated successfully',
      deleted: 'Library deleted successfully',
      notFound: 'Library not found',
      bookAdded: 'Book added to library inventory',
      bookRemoved: 'Book removed from library inventory'
    },
    validation: {
      failed: 'Validation failed',
      duplicateKey: 'Duplicate entry found',
      invalidId: 'Invalid ID format'
    },
    server: {
      internalError: 'Internal server error'
    }
  },
  hi: {
    auth: {
      tokenRequired: 'पहुंच टोकन आवश्यक है',
      userNotFound: 'उपयोगकर्ता नहीं मिला',
      invalidToken: 'अमान्य टोकन',
      unauthorized: 'अनधिकृत पहुंच',
      loginSuccess: 'लॉगिन सफल',
      registrationSuccess: 'उपयोगकर्ता सफलतापूर्वक पंजीकृत',
      invalidCredentials: 'अमान्य ईमेल या पासवर्ड'
    },
    book: {
      created: 'पुस्तक सफलतापूर्वक बनाई गई',
      updated: 'पुस्तक सफलतापूर्वक अपडेट की गई',
      deleted: 'पुस्तक सफलतापूर्वक हटाई गई',
      notFound: 'पुस्तक नहीं मिली',
      borrowed: 'पुस्तक सफलतापूर्वक उधार ली गई',
      returned: 'पुस्तक सफलतापूर्वक वापस की गई',
      alreadyBorrowed: 'पुस्तक पहले से ही उधार है',
      notBorrowed: 'पुस्तक वर्तमान में उधार नहीं है'
    },
    library: {
      created: 'पुस्तकालय सफलतापूर्वक बनाया गया',
      updated: 'पुस्तकालय सफलतापूर्वक अपडेट किया गया',
      deleted: 'पुस्तकालय सफलतापूर्वक हटाया गया',
      notFound: 'पुस्तकालय नहीं मिला',
      bookAdded: 'पुस्तक पुस्तकालय सूची में जोड़ी गई',
      bookRemoved: 'पुस्तक पुस्तकालय सूची से हटाई गई'
    },
    validation: {
      failed: 'सत्यापन असफल',
      duplicateKey: 'डुप्लिकेट प्रविष्टि मिली',
      invalidId: 'अमान्य आईडी प्रारूप'
    },
    server: {
      internalError: 'आंतरिक सर्वर त्रुटि'
    }
  }
};


const getLocalizedMessage = (key, language = 'en') => {
  const keys = key.split('.');
  let message = messages[language] || messages.en;
  
  for (const k of keys) {
    message = message[k];
    if (!message) {
      // Fallback to English if translation not found
      message = messages.en;
      for (const fallbackKey of keys) {
        message = message[fallbackKey];
        if (!message) return key;
      }
      break;
    }
  }
  
  return message || key;
};

module.exports = { getLocalizedMessage };
