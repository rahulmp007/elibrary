const USER_ROLES = {
  AUTHOR: "Author",
  BORROWER: "Borrower",
};

const BOOK_STATUS = {
  AVAILABLE: "available",
  BORROWED: "borrowed",
  MAINTENANCE: "maintenance",
};

const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  INTERNAL_SERVER_ERROR: 500,
};

const MESSAGES = {
  // Auth
  USER_CREATED: "User created successfully",
  LOGIN_SUCCESS: "Login successful",
  INVALID_CREDENTIALS: "Invalid credentials",
  TOKEN_REQUIRED: "Authorization token required",
  INVALID_TOKEN: "Invalid token",
  UNAUTHORIZED: "Unauthorized access",
  FORBIDDEN: "Access forbidden",

  // Books
  BOOK_CREATED: "Book created successfully",
  BOOK_UPDATED: "Book updated successfully",
  BOOK_DELETED: "Book deleted successfully",
  BOOK_NOT_FOUND: "Book not found",
  BOOK_BORROWED: "Book borrowed successfully",
  BOOK_RETURNED: "Book returned successfully",
  BOOK_ALREADY_BORROWED: "Book is already borrowed",
  BOOK_NOT_BORROWED: "Book is not currently borrowed",

  // Libraries
  LIBRARY_CREATED: "Library created successfully",
  LIBRARY_UPDATED: "Library updated successfully",
  LIBRARY_DELETED: "Library deleted successfully",
  LIBRARY_NOT_FOUND: "Library not found",
  BOOK_ADDED_TO_LIBRARY: "Book added to library inventory",
  BOOK_REMOVED_FROM_LIBRARY: "Book removed from library inventory",

  // Validation
  VALIDATION_ERROR: "Validation error",
  REQUIRED_FIELD: "This field is required",
  INVALID_EMAIL: "Invalid email format",
  PASSWORD_LENGTH: "Password must be at least 6 characters",

  // General
  SERVER_ERROR: "Internal server error",
  NOT_FOUND: "Resource not found",
};

module.exports = {
  USER_ROLES,
  BOOK_STATUS,
  HTTP_STATUS,
  MESSAGES,
};
