const User = require("./User.model");
const Book = require("./Book.model");
const Library = require("./Library.model");

module.exports = {
  User,
  Book,
  Library,
};
